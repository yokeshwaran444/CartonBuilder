﻿using Carton_Builder.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Net;

namespace Carton_Builder.Controllers
{
    public class CartonController : Controller
    {
        private readonly CartonDbContext _context;

        public CartonController(CartonDbContext context)
        {
            _context = context;
        }

        [HttpPost]
        public ActionResult RemoveEquipmentOnCarton(int cartonId, string serialNumber)
        {
            if (cartonId <= 0 || string.IsNullOrEmpty(serialNumber))
            {
                return Content("Invalid parameters");
            }

            var carton = _context.Carton.Include(c => c.CartonDetails)
                                         .FirstOrDefault(c => c.Id == cartonId);
            if (carton == null)
            {
                return Content("Carton not found");
            }        
            _context.SaveChanges();

            return RedirectToAction("Index");
        }

        //Allow Deletion of Cartons with Items
        [HttpPost]
        public ActionResult DeleteCarton(int cartonId)
        {
            var carton = _context.Carton.Find(cartonId);
            if (carton == null)
            {
                return Content("Carton not found");
            }

            _context.CartonDetails.RemoveRange(carton.CartonDetails); // Ensure related details are removed
            _context.Carton.Remove(carton);
            _context.SaveChanges();

            return RedirectToAction("Index");
        }

        ////Prevent Duplicate Equipment in Different Cartons
        [HttpPost]
        public ActionResult AddEquipmentToCarton(int cartonId, string serialNumber)
        {
            var equipment = _context.Equipment.FirstOrDefault(e => e.SerialNumber == serialNumber);
            if (equipment == null)
            {
                return Content("Equipment not found");
            }

            //var existingCarton = _context.CartonDetails
            //                             .Include(cd => cd.Carton)
            //                             .FirstOrDefault(cd => cd.Equipment.SerialNumber == serialNumber)?.Carton;

            //if (existingCarton != null && existingCarton.Id != cartonId)
            //{
            //    return Content("Equipment is already in another carton");
            //}

            var carton = _context.Carton.Include(c => c.CartonDetails)
                                         .FirstOrDefault(c => c.Id == cartonId);
            if (carton == null)
            {
                return Content("Carton not found");
            }

            if (carton.CartonDetails.Count >= 10)
            {
                return Content("Carton capacity reached");
            }
           
                _context.CartonDetails.Add(new CartonDetails
                {
                    CartonId = cartonId
                });
                _context.SaveChanges();            

            return RedirectToAction("Index");
        }

        //Limit Carton Capacity to 10 Pieces of Equipment
        public ActionResult Index()
        {
            var cartons = _context.Carton.Include(c => c.CartonDetails).ToList();
            var model = cartons.Select(c => new CartonViewModel
            {
                Id = c.Id,
                Name = c.Name,
                EquipmentCount = c.CartonDetails.Count
            }).ToList();

            return View(model);
        }

        //Remove All Items from a Carton
        [HttpPost]
        public ActionResult RemoveAllItemsFromCarton(int cartonId)
        {
            var carton = _context.Carton.Include(c => c.CartonDetails)
                                         .FirstOrDefault(c => c.Id == cartonId);
            if (carton == null)
            {
                return Content("Carton not found");
            }

            _context.CartonDetails.RemoveRange(carton.CartonDetails);
            _context.SaveChanges();

            return RedirectToAction("Index");
        }
    }
}

