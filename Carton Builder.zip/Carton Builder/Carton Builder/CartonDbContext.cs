﻿using Carton_Builder.Models;
using Microsoft.EntityFrameworkCore;

namespace Carton_Builder
{
    public class CartonDbContext : DbContext
    {
        public CartonDbContext(DbContextOptions<CartonDbContext> options)
         : base(options)
        {
        }

        public DbSet<Carton> Carton { get; set; }
        public DbSet<CartonDetails> CartonDetails { get; set; }
        public DbSet<Equipment> Equipment { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Equipment>()
                .HasNoKey();

            base.OnModelCreating(modelBuilder);
        }

    }
}