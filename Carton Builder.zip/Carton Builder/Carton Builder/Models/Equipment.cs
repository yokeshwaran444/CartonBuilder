﻿namespace Carton_Builder.Models
{
    public class Equipment
    {
        public string SerialNumber { get; set; }
        public string ModelType { get; set; }
    }

    public class Carton
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public ICollection<CartonDetails> CartonDetails { get; set; }
    }

    public class CartonDetails
    {
        public int Id { get; set; }
        public int CartonId { get; set; }
        public Carton Carton { get; set; }
        public string EquipmentSerialNumber { get; set; }        
    }
}
