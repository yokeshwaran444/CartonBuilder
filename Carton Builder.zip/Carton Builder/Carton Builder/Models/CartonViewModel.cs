﻿namespace Carton_Builder.Models
{
    public class CartonViewModel
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public int EquipmentCount { get; set; }
    }
}
